import { ScreenfullDirective } from './screenfull.directive';

describe('ScreenfullDirective', () => {
  it('should create an instance', () => {
    const directive = new ScreenfullDirective();
    expect(directive).toBeTruthy();
  });
});
