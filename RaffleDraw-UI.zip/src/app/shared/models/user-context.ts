export class UserContext {
    _id: string;
    userName: string;
    role: string;
    lastLoginDate: Date;
    userId: string;
    raffles: any;
}