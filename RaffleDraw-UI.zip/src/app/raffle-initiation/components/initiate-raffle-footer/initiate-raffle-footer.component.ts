import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-initiate-raffle-footer',
  templateUrl: './initiate-raffle-footer.component.html',
  styleUrls: ['./initiate-raffle-footer.component.css']
})
export class InitiateRaffleFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
