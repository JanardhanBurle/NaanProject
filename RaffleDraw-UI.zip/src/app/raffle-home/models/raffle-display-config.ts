export class RaffleDisplayConfig {
    animation: string;
    format: string;
    theme: string;
    value: number;
    duration: number;
    auto: boolean;
}