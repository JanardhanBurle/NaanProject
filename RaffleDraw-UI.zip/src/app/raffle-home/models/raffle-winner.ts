export class RaffleWinner {
    id: number;
    customerId: any;
    name: string;
    accountNumber: string;
    prize: string;
    prizeName: string;
    raffleCode: number;
}

