export class Prize {
    id: number;
    name: string;
    content: any;
    fileStatus: string;
}