import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raffle-management',
  templateUrl: './raffle-management.component.html',
  styleUrls: ['./raffle-management.component.css']
})
export class RaffleManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
