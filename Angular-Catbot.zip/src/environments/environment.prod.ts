export const environment = {
  production: true,
  dialogflow: {
    angularBot: "55063d8db0254ea99c984f21f4727199"
  }
};
