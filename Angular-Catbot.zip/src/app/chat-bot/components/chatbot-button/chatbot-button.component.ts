import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatbot-button',
  templateUrl: './chatbot-button.component.html',
  styleUrls: ['./chatbot-button.component.css']
})
export class ChatbotButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
